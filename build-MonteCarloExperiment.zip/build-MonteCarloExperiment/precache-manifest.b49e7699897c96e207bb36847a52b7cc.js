self.__precacheManifest = [
  {
    "revision": "c2dd8d3e161f6672cf93",
    "url": "/static/css/main.c5516e75.chunk.css"
  },
  {
    "revision": "c2dd8d3e161f6672cf93",
    "url": "/static/js/main.fc30575e.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "79b36ff4709d8859aaf2",
    "url": "/static/js/2.92bf9184.chunk.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "19787b51c543fd7bf447f0adb03d4d36",
    "url": "/index.html"
  }
];